# Gửi những bông hoa 10A06 💗

Website chúc mừng ngày 20/10 dành cho các bạn nữ lớp 10A06, phong cách hồng pastel.

## Có gì trong trang web?
- Hiệu ứng trái tim, hoa và nơ bay nhẹ nhàng
- Phong thư tương tác có thể mở/đóng
- Hũ lời chúc ngẫu nhiên
- Danh sách 29 bạn nữ
- Scrapbook mẫu để sau này thay bằng ảnh thật
- Nút bật/tắt giai điệu nền được tạo trực tiếp trong trình duyệt
- Hiệu ứng xuất hiện khi cuộn và lấp lánh khi bấm
- Tương thích điện thoại và máy tính; tôn trọng cài đặt giảm chuyển động

## Đưa lên GitHub Pages
1. Tạo repository mới trên GitHub, ví dụ `10a06-20-10`.
2. Giải nén file ZIP này.
3. Upload `index.html` lên thư mục gốc của repo và Commit changes.
4. Vào **Settings → Pages**.
5. Chọn **Deploy from a branch**, branch `main`, folder `/(root)`, rồi Save.
6. Chờ GitHub Pages xuất bản. Đường dẫn thường là `https://TEN-GITHUB.github.io/10a06-20-10/`.

## Chỉnh sửa
- Toàn bộ website nằm trong `index.html`.
- Danh sách tên nằm trong mảng `girls` ở cuối file.
- Các lời chúc nằm trong mảng `wishes`.
- Các khung scrapbook hiện là minh họa bằng emoji; có thể thay bằng ảnh lớp khi có ảnh thật.

Lưu ý: Nhạc nền là giai điệu nhẹ tạo bằng Web Audio API, không cần tải file nhạc ngoài. Trình duyệt yêu cầu người dùng nhấn nút để bật âm thanh.


## Bản nâng cấp hiệu ứng bất ngờ
Bản này bổ sung: đếm ngược mở quà, bầu trời sao tương tác cho 29 bạn nữ, nhiệm vụ săn 3 trái tim mở khóa lời nhắn cuối, hiệu ứng pháo giấy và 3 trái tim bí mật ở mép trang.

### Cập nhật lên GitHub Pages
1. Giải nén file ZIP.
2. Mở repository website 20/10 của lớp trên GitHub.
3. Chọn `Add file` → `Upload files`, tải `index.html` mới lên và chọn ghi đè file cũ.
4. Bấm `Commit changes`.
5. Vào `Settings` → `Pages`, kiểm tra nguồn triển khai đang dùng nhánh `main` và thư mục `/ (root)`. Đợi một chút rồi mở lại trang.

Nếu chưa tạo repository cho website 20/10, tạo repo riêng tên `10a06-20-10`, sau đó tải `index.html` lên repo đó và bật GitHub Pages như hướng dẫn trên.
